/**
 * Espressolab coffee shop — doğrulanmış şube proforma listeleri.
 * Motor varsayılanı: COFFEE_SHOP_DEFAULT_REFERANS_ID
 */

import type { CoffeeShopReferansProfil } from "./coffee-shop-types";

/** Şube 1 — geniş set (3+2 kapılı soğutucu, depo G, çift tezgah) */
const ESPRESSOLAB_SUBE_1: CoffeeShopReferansProfil = {
  id: "espressolab-sube-1",
  label: "Espressolab şube 1 (geniş)",
  not: "3 kapılı + 2×2 kapılı şişe soğutucu; depo tipi derin dondurucu + buzdolabı.",
  kalemler: [
    { referansPoz: "A1", isim: "Soğuk Teşhir Dolabı (İçecek + Pasta)", urunTipi: "soguk-tesir-dolabi-pastane", kategoriKodu: "D", adet: 1, notlar: "250*100*140", elektrikGucuKwHint: 0.4 },
    { referansPoz: "A2", isim: "Çalışma Tezgahı, Kasa ve Kahve Çekmeceli, Taban Raflı", urunTipi: "calisma-tezgahi-kasa-kahve", kategoriKodu: "A", adet: 1, notlar: "120*70*85" },
    { referansPoz: "A4", isim: "Espresso Kahve Makinası", urunTipi: "espresso-2-grup", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 3.5 },
    { referansPoz: "A5", isim: "Kahve Değirmeni", urunTipi: "kahve-degirmeni", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 0.3 },
    { referansPoz: "A6", isim: "Şişe Soğutucu, Üç Kapılı", urunTipi: "sise-sogutucu-3-kapili", kategoriKodu: "A", adet: 1, notlar: "135*50*90", elektrikGucuKwHint: 0.2 },
    { referansPoz: "A6A", isim: "Şişe Soğutucu, İki Kapılı", urunTipi: "sise-sogutucu-2-kapili", kategoriKodu: "A", adet: 2, notlar: "90*50*90", elektrikGucuKwHint: 0.2 },
    { referansPoz: "A7", isim: "Çöp Tezgahı", urunTipi: "cop-tezgahi", kategoriKodu: "A", adet: 1, notlar: "50*70*85" },
    { referansPoz: "A8", isim: "Çöp Arabası", urunTipi: "cop-arabasi", kategoriKodu: "A", adet: 1, notlar: "40*40*50" },
    { referansPoz: "A11", isim: "Evye Tezgahı, Dolaplı, Siyah Boyalı", urunTipi: "evye-tezgahi-dolapli", kategoriKodu: "A", adet: 1, notlar: "100*70*85" },
    { referansPoz: "A12", isim: "40*40*25 Küvet", urunTipi: "bar-kuvet-40", kategoriKodu: "A", adet: 1 },
    { referansPoz: "A13", isim: "Rinser Evyesi", urunTipi: "rinser-evyesi", kategoriKodu: "A", adet: 2 },
    { referansPoz: "A14", isim: "Buz Makinası", urunTipi: "buz-makinesi-90kg", kategoriKodu: "A", adet: 1, notlar: "90 kg/gün", elektrikGucuKwHint: 0.6 },
    { referansPoz: "A15", isim: "Bardak Yıkama Makinası, Durulama ve Tahliye Pompalı", urunTipi: "glass-washer", kategoriKodu: "A", adet: 1, notlar: "60*60*82", elektrikGucuKwHint: 2.5 },
    { referansPoz: "A16", isim: "Merrychef", urunTipi: "speed-oven-merry-chef", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 3.2 },
    { referansPoz: "A17", isim: "Fırın Unox", urunTipi: "konveksiyon-firin-unox", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 3.0 },
    { referansPoz: "A18", isim: "Çalışma Tezgahı, Dolaplı, Siyah Boyalı", urunTipi: "calisma-tezgahi-dolapli", kategoriKodu: "A", adet: 1, notlar: "140*60*85" },
    { referansPoz: "A19", isim: "Çalışma Tezgahı, Dolaplı, Siyah Boyalı", urunTipi: "calisma-tezgahi-dolapli-2", kategoriKodu: "A", adet: 1, notlar: "140*60*85" },
    { referansPoz: "A20", isim: "Bar Blender", urunTipi: "bar-blender", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 1.5 },
    { referansPoz: "A21", isim: "Kahve Makinası", urunTipi: "kahve-makinasi-turk", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 1.5 },
    { referansPoz: "A22", isim: "Katı Meyve Sıkacağı", urunTipi: "kati-meyve-sikacagi", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 0.25 },
    { referansPoz: "A23", isim: "Bar Mikser", urunTipi: "bar-mikser", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 0.3 },
    { referansPoz: "A24", isim: "Filtre Kahve Makinası", urunTipi: "filter-coffee-makinesi", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 2.0 },
    { referansPoz: "A25", isim: "Filtre Kahve Makinası", urunTipi: "filter-coffee-makinesi-2", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 2.0 },
    { referansPoz: "A26", isim: "Yer Izgarası", urunTipi: "yer-izgara-kucuk", kategoriKodu: "A", adet: 1, notlar: "30*30*14" },
    { referansPoz: "A27", isim: "Depo Tipi Derin Dondurucu", urunTipi: "depo-derin-dondurucu", kategoriKodu: "G", adet: 1, notlar: "70*70*205", elektrikGucuKwHint: 0.3 },
    { referansPoz: "A28", isim: "Depo Tipi Buzdolabı", urunTipi: "depo-buzdolabi-tek-kapili", kategoriKodu: "G", adet: 1, notlar: "70*70*205", elektrikGucuKwHint: 0.4 },
  ],
};

/** Şube 2 — kompakt (setaltı derin dondurucu, montaj A27) */
const ESPRESSOLAB_SUBE_2: CoffeeShopReferansProfil = {
  id: "espressolab-sube-2",
  label: "Espressolab şube 2 (kompakt)",
  not: "3 kapılı şişe soğutucu ×2; setaltı derin dondurucu; A3/A9 yok.",
  kalemler: [
    { referansPoz: "A1", isim: "Soğuk Teşhir Dolabı (İçecek + Pasta + Nötr)", urunTipi: "soguk-tesir-dolabi-pastane", kategoriKodu: "D", adet: 1, notlar: "250*100*140", elektrikGucuKwHint: 0.4 },
    { referansPoz: "A2", isim: "Çalışma Tezgahı, Kasa ve Kahve Çekmeceli, Taban Raflı", urunTipi: "calisma-tezgahi-kasa-kahve", kategoriKodu: "A", adet: 1, notlar: "70*70*85" },
    { referansPoz: "A4", isim: "Espresso Kahve Makinası", urunTipi: "espresso-2-grup", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 3.5 },
    { referansPoz: "A5", isim: "Kahve Değirmeni", urunTipi: "kahve-degirmeni", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 0.3 },
    { referansPoz: "A6", isim: "Şişe Soğutucu, Üç Kapılı", urunTipi: "sise-sogutucu-3-kapili", kategoriKodu: "A", adet: 2, notlar: "135*50*90", elektrikGucuKwHint: 0.2 },
    { referansPoz: "A7", isim: "Çalışma Tezgahı, Taban ve Ara Raflı", urunTipi: "calisma-tezgahi-taban-ara", kategoriKodu: "A", adet: 1, notlar: "120*70*85" },
    { referansPoz: "A8", isim: "Çöp Arabası", urunTipi: "cop-arabasi", kategoriKodu: "A", adet: 1, notlar: "40*40*50" },
    { referansPoz: "A10", isim: "Çöp Tezgahı, Çekmeceli, Siyah Boyalı, Raylı", urunTipi: "cop-tezgahi", kategoriKodu: "A", adet: 1, notlar: "50*70*85" },
    { referansPoz: "A11", isim: "Evye Tezgahı, Dolaplı, Siyah Boyalı", urunTipi: "evye-tezgahi-dolapli", kategoriKodu: "A", adet: 1, notlar: "100*70*85" },
    { referansPoz: "A12", isim: "40*40*25 Küvet", urunTipi: "bar-kuvet-40", kategoriKodu: "A", adet: 1 },
    { referansPoz: "A13", isim: "Rinser Evyesi", urunTipi: "rinser-evyesi", kategoriKodu: "A", adet: 1 },
    { referansPoz: "A14", isim: "Buz Makinası", urunTipi: "buz-makinesi-90kg", kategoriKodu: "A", adet: 1, notlar: "90 kg/gün", elektrikGucuKwHint: 0.6 },
    { referansPoz: "A15", isim: "Bardak Yıkama Makinası, Durulama ve Tahliye Pompalı", urunTipi: "glass-washer", kategoriKodu: "A", adet: 1, notlar: "60*60*82", elektrikGucuKwHint: 2.5 },
    { referansPoz: "A16", isim: "Merrychef", urunTipi: "speed-oven-merry-chef", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 3.2 },
    { referansPoz: "A17", isim: "Fırın Unox", urunTipi: "konveksiyon-firin-unox", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 3.0 },
    { referansPoz: "A18", isim: "Tezgah, Dolaplı, Siyah Boyalı", urunTipi: "calisma-tezgahi-dolapli-70", kategoriKodu: "A", adet: 1, notlar: "70*70*85" },
    { referansPoz: "A19", isim: "Setaltı Derindondurucu, Tek Kapılı", urunTipi: "setalti-derin-dondurucu", kategoriKodu: "A", adet: 1, notlar: "60*60*82", elektrikGucuKwHint: 0.3 },
    { referansPoz: "A20", isim: "Bar Blender", urunTipi: "bar-blender", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 1.5 },
    { referansPoz: "A21", isim: "Kahve Makinası", urunTipi: "kahve-makinasi-turk", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 1.5 },
    { referansPoz: "A22", isim: "Katı Meyve Sıkacağı", urunTipi: "kati-meyve-sikacagi", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 0.25 },
    { referansPoz: "A23", isim: "Bar Mikser", urunTipi: "bar-mikser", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 0.3 },
    { referansPoz: "A24", isim: "Filtre Kahve Makinası", urunTipi: "filter-coffee-makinesi", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 2.0 },
    { referansPoz: "A25", isim: "Filtre Kahve Makinası", urunTipi: "filter-coffee-makinesi-2", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 2.0 },
    { referansPoz: "A26", isim: "Yer Izgarası", urunTipi: "yer-izgara-kucuk", kategoriKodu: "A", adet: 1, notlar: "30*30*14" },
    { referansPoz: "A27", isim: "Montaj Nakliye", urunTipi: "montaj-nakliye", kategoriKodu: "X", adet: 1 },
  ],
};

/** Şube 3 — tam set (içecek havuzu, ek tezgahlar, depo + istif raf) */
const ESPRESSOLAB_SUBE_3: CoffeeShopReferansProfil = {
  id: "espressolab-sube-3",
  label: "Espressolab şube 3 (tam)",
  not: "A1A içecek havuzu; A9–A10 ek tezgahlar; A26 yer ızgarası ×3; A27–A29 depo.",
  kalemler: [
    { referansPoz: "A1", isim: "Soğuk Teşhir Dolabı", urunTipi: "soguk-tesir-dolabi-pastane", kategoriKodu: "D", adet: 1, notlar: "170*80*145", elektrikGucuKwHint: 0.4 },
    { referansPoz: "A1A", isim: "İçecek Havuzu Soğuk", urunTipi: "icecek-havuzu-soguk", kategoriKodu: "A", adet: 1, notlar: "60*70*100", elektrikGucuKwHint: 0.3 },
    { referansPoz: "A2", isim: "Çalışma Tezgahı, Kasa ve Kahve Çekmeceli, Taban Raflı", urunTipi: "calisma-tezgahi-kasa-kahve", kategoriKodu: "A", adet: 1, notlar: "120*70*85" },
    { referansPoz: "A4", isim: "Espresso Kahve Makinası", urunTipi: "espresso-2-grup", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 3.5 },
    { referansPoz: "A5", isim: "Kahve Değirmeni", urunTipi: "kahve-degirmeni", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 0.3 },
    { referansPoz: "A6", isim: "Şişe Soğutucu, Üç Kapılı", urunTipi: "sise-sogutucu-3-kapili", kategoriKodu: "A", adet: 1, notlar: "135*50*90", elektrikGucuKwHint: 0.2 },
    { referansPoz: "A6A", isim: "Şişe Soğutucu, İki Kapılı", urunTipi: "sise-sogutucu-2-kapili", kategoriKodu: "A", adet: 1, notlar: "90*50*90", elektrikGucuKwHint: 0.2 },
    { referansPoz: "A7", isim: "Çalışma Tezgahı, Taban ve Ara Raflı, Dolaplı", urunTipi: "calisma-tezgahi-taban-ara-dolapli", kategoriKodu: "A", adet: 1, notlar: "120*70*85" },
    { referansPoz: "A8", isim: "Çöp Arabası", urunTipi: "cop-arabasi", kategoriKodu: "A", adet: 1, notlar: "40*40*50" },
    { referansPoz: "A9", isim: "Çalışma Tezgahı, Taban ve Ara Raflı", urunTipi: "calisma-tezgahi-taban-ara-90", kategoriKodu: "A", adet: 1, notlar: "90*70*85" },
    { referansPoz: "A10", isim: "Çalışma Tezgahı, Taban ve Ara Raflı, Dolaplı", urunTipi: "calisma-tezgahi-taban-ara-dolapli-90", kategoriKodu: "A", adet: 1, notlar: "90*70*85" },
    { referansPoz: "A11", isim: "Evye Tezgahı, Dolaplı, Siyah Boyalı", urunTipi: "evye-tezgahi-dolapli", kategoriKodu: "A", adet: 1, notlar: "100*70*85" },
    { referansPoz: "A12", isim: "40*40*25 Küvet", urunTipi: "bar-kuvet-40", kategoriKodu: "A", adet: 1 },
    { referansPoz: "A13", isim: "Rinser Evyesi", urunTipi: "rinser-evyesi", kategoriKodu: "A", adet: 1 },
    { referansPoz: "A14", isim: "Buz Makinası", urunTipi: "buz-makinesi-90kg", kategoriKodu: "A", adet: 1, notlar: "90 kg/gün", elektrikGucuKwHint: 0.6 },
    { referansPoz: "A15", isim: "Bardak Yıkama Makinası, Durulama ve Tahliye Pompalı", urunTipi: "glass-washer", kategoriKodu: "A", adet: 1, notlar: "60*60*82", elektrikGucuKwHint: 2.5 },
    { referansPoz: "A16", isim: "Merrychef", urunTipi: "speed-oven-merry-chef", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 3.2 },
    { referansPoz: "A17", isim: "Fırın Unox", urunTipi: "konveksiyon-firin-unox", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 3.0 },
    { referansPoz: "A18", isim: "Tezgah, Dolaplı, Siyah Boyalı", urunTipi: "calisma-tezgahi-dolapli-70", kategoriKodu: "A", adet: 1, notlar: "70*70*85" },
    { referansPoz: "A19", isim: "Setaltı Derindondurucu, Tek Kapılı", urunTipi: "setalti-derin-dondurucu", kategoriKodu: "A", adet: 1, notlar: "60*60*82", elektrikGucuKwHint: 0.3 },
    { referansPoz: "A20", isim: "Bar Blender", urunTipi: "bar-blender", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 1.5 },
    { referansPoz: "A21", isim: "Kahve Makinası", urunTipi: "kahve-makinasi-turk", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 1.5 },
    { referansPoz: "A22", isim: "Katı Meyve Sıkacağı", urunTipi: "kati-meyve-sikacagi", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 0.25 },
    { referansPoz: "A23", isim: "Bar Mikser", urunTipi: "bar-mikser", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 0.3 },
    { referansPoz: "A24", isim: "Filtre Kahve Makinası", urunTipi: "filter-coffee-makinesi", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 2.0 },
    { referansPoz: "A25", isim: "Filtre Kahve Makinası", urunTipi: "filter-coffee-makinesi-2", kategoriKodu: "A", adet: 1, elektrikGucuKwHint: 2.0 },
    { referansPoz: "A26", isim: "Yer Izgarası", urunTipi: "yer-izgara-kucuk", kategoriKodu: "A", adet: 3, notlar: "30*30*14" },
    { referansPoz: "A27", isim: "Depo Tipi Derin Dondurucu, Çift Kapılı", urunTipi: "depo-derin-dondurucu-cift-kapili", kategoriKodu: "G", adet: 1, notlar: "140*70*205", elektrikGucuKwHint: 0.3 },
    { referansPoz: "A28", isim: "Depo Tipi Buzdolabı, Tek Kapılı", urunTipi: "depo-buzdolabi-tek-kapili", kategoriKodu: "G", adet: 1, notlar: "70*70*205", elektrikGucuKwHint: 0.4 },
    { referansPoz: "A29", isim: "İstif Rafı", urunTipi: "kuru-depo-raf", kategoriKodu: "G", adet: 1, notlar: "137*53*160" },
    { referansPoz: "A30", isim: "Nakliye Montaj", urunTipi: "montaj-nakliye", kategoriKodu: "X", adet: 1 },
  ],
};

export const COFFEE_SHOP_ESPRESSOLAB_REFERANSLAR: CoffeeShopReferansProfil[] = [
  ESPRESSOLAB_SUBE_1,
  ESPRESSOLAB_SUBE_2,
  ESPRESSOLAB_SUBE_3,
];

/** Motor / teklif önizleme varsayılanı */
export const COFFEE_SHOP_DEFAULT_REFERANS_ID = "espressolab-sube-3";

export function getCoffeeShopReferans(id: string): CoffeeShopReferansProfil {
  const found = COFFEE_SHOP_ESPRESSOLAB_REFERANSLAR.find((r) => r.id === id);
  if (!found) {
    throw new Error(`Coffee shop referans bulunamadı: ${id}`);
  }
  return found;
}

export function listCoffeeShopReferanslar(): Pick<
  CoffeeShopReferansProfil,
  "id" | "label" | "not"
>[] {
  return COFFEE_SHOP_ESPRESSOLAB_REFERANSLAR.map(({ id, label, not }) => ({
    id,
    label,
    not,
  }));
}
